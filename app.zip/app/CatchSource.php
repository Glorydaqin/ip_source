<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CatchSource extends Model
{
    //
    protected $table="ip_catch_source";
}
