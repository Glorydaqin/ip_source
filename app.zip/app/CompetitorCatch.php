<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompetitorCatch extends Model
{
    //
    protected $table="ip_competitor_catch";
}
